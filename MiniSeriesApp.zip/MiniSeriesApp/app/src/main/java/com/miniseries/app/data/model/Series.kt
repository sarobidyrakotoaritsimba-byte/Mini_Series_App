package com.miniseries.app.data.model

/**
 * Une mini-série contient une liste d'épisodes courts.
 */
data class Series(
    val id: String,
    val title: String,
    val description: String,
    val coverUrl: String,
    val genre: String,
    val episodes: List<Episode>,
    val isTrending: Boolean = false
)

/**
 * Un épisode individuel (1-3 min typiquement).
 * freeEpisodeLimit détermine combien d'épisodes sont gratuits avant le paywall.
 */
data class Episode(
    val id: String,
    val seriesId: String,
    val episodeNumber: Int,
    val title: String,
    val videoUrl: String,
    val thumbnailUrl: String,
    val durationSeconds: Int,
    val isLocked: Boolean = false
)

/**
 * Représente un item du feed vertical : soit un épisode en lecture directe,
 * soit une carte "découverte" d'une nouvelle série.
 */
sealed class FeedItem {
    data class EpisodeItem(val episode: Episode, val series: Series) : FeedItem()
}
