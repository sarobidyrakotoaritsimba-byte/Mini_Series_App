# Mini Séries — Prototype Android

Feed vertical type ReelShort/DramaBox : scroll d'épisodes courts avec lecture
vidéo autoplay, système de pièces virtuelles et paywall à l'épisode 4.

## Comment l'ouvrir
1. Ouvre Android Studio (Koala ou plus récent recommandé).
2. `File > Open` → sélectionne le dossier `MiniSeriesApp`.
3. Laisse Gradle synchroniser (première fois = quelques minutes).
4. Lance sur un émulateur ou un téléphone (`Run > Run 'app'`).

## Ce qui est déjà fonctionnel
- Feed vertical scrollable (`VerticalPager`) avec lecture vidéo auto (ExoPlayer/Media3)
- Lecture/pause automatique selon la page visible (pas de son superposé)
- Overlay titre/description/genre par épisode
- Système de pièces virtuelles (mock) + paywall à partir de l'épisode 4
- Architecture MVVM propre, prête à brancher un vrai backend

## Ce qu'il reste à faire pour un vrai lancement
- Remplacer `SeriesRepository` (mock) par de vrais appels réseau (Firebase/Retrofit)
- Héberger le vrai contenu vidéo (actuellement des vidéos de démo Google)
- Intégrer Google Play Billing pour l'achat réel de pièces/abonnements
- Auth utilisateur (Firebase Auth ou autre)
- Écran de recherche + catégories
- Icônes de lancement (`mipmap`) — actuellement absentes, à ajouter avant la build finale

## Structure du projet
```
app/src/main/java/com/miniseries/app/
├── MainActivity.kt
├── data/
│   ├── model/Series.kt          # Series, Episode
│   └── repository/SeriesRepository.kt  # données mock
├── ui/
│   ├── feed/FeedScreen.kt       # écran principal (pager vertical)
│   └── player/VideoPlayer.kt    # wrapper ExoPlayer pour Compose
└── viewmodel/FeedViewModel.kt   # état du feed, paywall, pièces
```
