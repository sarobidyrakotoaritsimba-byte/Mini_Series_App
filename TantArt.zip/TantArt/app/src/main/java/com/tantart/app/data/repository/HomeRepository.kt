package com.tantart.app.data.repository

import com.tantart.app.data.model.ContinueWatchingItem
import com.tantart.app.data.model.HeroContent
import com.tantart.app.data.model.HomeCategory

/**
 * Repository mock pour la page d'accueil.
 * S'appuie sur SeriesRepository (même source de vérité que le Feed) pour
 * que l'accueil et le feed restent cohérents. À terme, remplacer par de
 * vrais appels réseau (Firebase/Retrofit) — la forme des données ci-dessous
 * (HeroContent, ContinueWatchingItem, HomeCategory) est déjà prête pour ça.
 */
object HomeRepository {

    fun getHero(): HeroContent {
        val trending = SeriesRepository.getMockSeriesList().first { it.isTrending }
        return HeroContent(series = trending)
    }

    fun getContinueWatching(): List<ContinueWatchingItem> {
        val progressValues = listOf(0.4f, 0.65f, 0.15f, 0.8f)
        return SeriesRepository.getMockSeriesList().mapIndexed { index, series ->
            ContinueWatchingItem(
                series = series,
                currentEpisodeNumber = (index % series.episodes.size) + 1,
                totalEpisodes = series.episodes.size,
                progressFraction = progressValues[index % progressValues.size]
            )
        }
    }

    fun getCategories(): List<HomeCategory> {
        return listOf(
            HomeCategory("Drame"),
            HomeCategory("Romance"),
            HomeCategory("Mystère"),
            HomeCategory("Action"),
            HomeCategory("Thriller"),
            HomeCategory("Comédie")
        )
    }
}
