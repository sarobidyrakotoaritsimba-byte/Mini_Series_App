package com.tantart.app.data.repository

import com.tantart.app.data.model.Episode
import com.tantart.app.data.model.Series

/**
 * Repository mock pour le prototype.
 * À remplacer par de vrais appels réseau (Retrofit/Firestore) en production.
 * Les URLs vidéo pointent vers des exemples libres Google (Big Buck Bunny, etc.)
 * uniquement pour tester la lecture — à remplacer par ton propre contenu/CDN.
 */
object SeriesRepository {

    private val sampleVideoUrls = listOf(
        "https://developer.mozilla.org/shared-assets/videos/flower.mp4",
        "https://developer.mozilla.org/shared-assets/videos/flower.mp4",
        "https://developer.mozilla.org/shared-assets/videos/flower.mp4",
        "https://developer.mozilla.org/shared-assets/videos/flower.mp4"
    )

    fun getMockSeriesList(): List<Series> {
        return listOf(
            buildSeries(
                id = "s1",
                title = "Le Secret de l'Héritière",
                description = "Elle a tout perdu... jusqu'à ce qu'elle découvre la vérité sur sa famille.",
                genre = "Drame",
                isTrending = true
            ),
            buildSeries(
                id = "s2",
                title = "Mariage de Convenance",
                description = "Un contrat de mariage qui va bouleverser deux vies.",
                genre = "Romance"
            ),
            buildSeries(
                id = "s3",
                title = "Vengeance CEO",
                description = "Il est revenu pour reprendre ce qui lui appartient.",
                genre = "Thriller",
                isTrending = true
            )
        )
    }

    private fun buildSeries(
        id: String,
        title: String,
        description: String,
        genre: String,
        isTrending: Boolean = false
    ): Series {
        val episodes = (1..8).map { epNum ->
            Episode(
                id = "$id-ep$epNum",
                seriesId = id,
                episodeNumber = epNum,
                title = "Épisode $epNum",
                videoUrl = sampleVideoUrls[epNum % sampleVideoUrls.size],
                thumbnailUrl = "https://picsum.photos/seed/$id-$epNum/400/700",
                durationSeconds = 90 + (epNum * 5),
                isLocked = epNum > 3 // 3 premiers épisodes gratuits
            )
        }
        return Series(
            id = id,
            title = title,
            description = description,
            coverUrl = "https://picsum.photos/seed/$id/400/700",
            genre = genre,
            episodes = episodes,
            isTrending = isTrending
        )
    }

    /** Retourne le feed d'épisodes à la suite, façon TikTok, tous mélangés. */
    fun getFeedEpisodes(): List<Pair<Episode, Series>> {
        return getMockSeriesList().flatMap { series ->
            series.episodes.map { episode -> episode to series }
        }
    }
}
