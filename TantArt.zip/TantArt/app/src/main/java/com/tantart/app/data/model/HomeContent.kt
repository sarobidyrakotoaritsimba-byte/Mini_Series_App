package com.tantart.app.data.model

/** Élément mis en avant dans le grand bandeau "Hero" de l'accueil. */
data class HeroContent(
    val series: Series,
    val badgeLabel: String = "TOP 1",
    val isOriginal: Boolean = true
)

/** Une série en cours de visionnage, avec sa progression. */
data class ContinueWatchingItem(
    val series: Series,
    val currentEpisodeNumber: Int,
    val totalEpisodes: Int,
    val progressFraction: Float // 0f à 1f, position dans l'épisode en cours
)

/** Catégorie/genre affiché dans "Explorer par catégorie". */
data class HomeCategory(
    val name: String
)
