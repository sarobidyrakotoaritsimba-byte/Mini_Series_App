package com.tantart.app.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.tantart.app.data.model.Episode
import com.tantart.app.data.model.Series
import com.tantart.app.data.repository.SeriesRepository

class FeedViewModel : ViewModel() {

    // Liste des (épisode, série) affichée dans le feed vertical
    var feedItems by mutableStateOf<List<Pair<Episode, Series>>>(emptyList())
        private set

    // Index actuellement visible dans le pager (pour piloter play/pause)
    var currentIndex by mutableStateOf(0)
        private set

    // Contrôle l'affichage du paywall
    var showPaywall by mutableStateOf(false)
        private set

    var lockedEpisode: Episode? = null
        private set

    // Simule des pièces virtuelles possédées par l'utilisateur
    var userCoins by mutableStateOf(50)
        private set

    init {
        feedItems = SeriesRepository.getFeedEpisodes()
    }

    fun onPageChanged(newIndex: Int) {
        currentIndex = newIndex
        val (episode, _) = feedItems.getOrNull(newIndex) ?: return
        if (episode.isLocked) {
            lockedEpisode = episode
            showPaywall = true
        }
    }

    fun dismissPaywall() {
        showPaywall = false
    }

    fun unlockWithCoins(cost: Int = 20): Boolean {
        if (userCoins >= cost) {
            userCoins -= cost
            showPaywall = false
            // Débloque l'épisode localement pour ce prototype
            lockedEpisode?.let { locked ->
                feedItems = feedItems.map { (ep, series) ->
                    if (ep.id == locked.id) ep.copy(isLocked = false) to series else ep to series
                }
            }
            return true
        }
        return false
    }
}
