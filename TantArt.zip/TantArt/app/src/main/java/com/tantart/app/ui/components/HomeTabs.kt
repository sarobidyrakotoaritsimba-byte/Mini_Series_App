package com.tantart.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tantart.app.ui.theme.TantPink
import com.tantart.app.ui.theme.TantTextMuted

val homeTabLabels = listOf("Pour vous", "Séries", "Nouveautés", "Genres")

/** Rangée d'onglets horizontaux sous le header de l'accueil. */
@Composable
fun HomeTabs(
    selectedTab: String,
    onTabSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyRow(
        modifier = modifier.fillMaxWidth().padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(22.dp)
    ) {
        items(homeTabLabels) { label ->
            val isSelected = label == selectedTab
            Column(
                modifier = Modifier
                    .clickable { onTabSelected(label) }
                    .padding(vertical = 8.dp)
            ) {
                Text(
                    text = label,
                    color = if (isSelected) TantPink else TantTextMuted,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                )
                if (isSelected) {
                    Box(
                        modifier = Modifier
                            .padding(top = 6.dp)
                            .height(2.dp)
                            .width(28.dp)
                            .background(TantPink)
                    )
                }
            }
        }
    }
}
