package com.tantart.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.tantart.app.R
import com.tantart.app.ui.theme.TantOrange
import com.tantart.app.ui.theme.TantPink
import com.tantart.app.ui.theme.TantPurple
import com.tantart.app.ui.theme.TantTextPrimary

/**
 * En-tête réutilisable en haut des écrans principaux : logo TantArt,
 * badge de pièces, recherche et notifications.
 *
 * @param notificationCount si > 0, affiche un badge rouge avec ce nombre.
 */
@Composable
fun TopHeader(
    coins: Int,
    notificationCount: Int = 0,
    onSearchClick: () -> Unit = {},
    onNotificationsClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Logo officiel TantArt. weight(fill = false) : se réduit en priorité
        // sur petits écrans, avant que les icônes ne soient impactées.
        androidx.compose.foundation.Image(
            painter = painterResource(R.drawable.tantart_logo_header),
            contentDescription = "TantArt",
            modifier = Modifier
                .weight(1f, fill = false)
                .heightIn(max = 40.dp),
            contentScale = ContentScale.Fit
        )

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            CoinCounter(coins = coins)
            IconButton(onClick = onSearchClick) {
                Icon(imageVector = Icons.Filled.Search, contentDescription = "Rechercher", tint = TantTextPrimary)
            }
            Box {
                IconButton(onClick = onNotificationsClick) {
                    Icon(imageVector = Icons.Filled.Notifications, contentDescription = "Notifications", tint = TantTextPrimary)
                }
                if (notificationCount > 0) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(top = 6.dp, end = 6.dp)
                            .background(Color.Red, RoundedCornerShape(50))
                            .padding(horizontal = 5.dp, vertical = 1.dp)
                    ) {
                        Text(text = "$notificationCount", color = Color.White, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

/** Compteur de pièces réutilisable, dégradé signature TantArt. */
@Composable
fun CoinCounter(coins: Int, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(
                androidx.compose.ui.graphics.Brush.horizontalGradient(listOf(TantPurple, TantPink, TantOrange)),
                RoundedCornerShape(50)
            )
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Text(text = "🪙 $coins", color = Color.White, style = MaterialTheme.typography.labelMedium)
    }
}
