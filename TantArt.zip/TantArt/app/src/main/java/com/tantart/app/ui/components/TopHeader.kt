package com.tantart.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tantart.app.ui.theme.TantGold
import com.tantart.app.ui.theme.TantOrange
import com.tantart.app.ui.theme.TantPink
import com.tantart.app.ui.theme.TantPurple
import com.tantart.app.ui.theme.TantTextPrimary

/**
 * En-tête réutilisable en haut des écrans principaux : logo TantArt,
 * badge de pièces, recherche et notifications.
 *
 * @param notificationCount si > 0, affiche un badge rouge avec ce nombre.
 */
@Composable
fun TopHeader(
    coins: Int,
    notificationCount: Int = 0,
    onSearchClick: () -> Unit = {},
    onNotificationsClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Logo : "Tant" en blanc + "Art" en dégradé, comme la charte
        Row {
            Text(text = "Tant", color = TantTextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(text = "Art", color = TantPink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            CoinCounter(coins = coins)
            IconButton(onClick = onSearchClick) {
                Icon(imageVector = Icons.Filled.Search, contentDescription = "Rechercher", tint = TantTextPrimary)
            }
            Box {
                IconButton(onClick = onNotificationsClick) {
                    Icon(imageVector = Icons.Filled.Notifications, contentDescription = "Notifications", tint = TantTextPrimary)
                }
                if (notificationCount > 0) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(top = 6.dp, end = 6.dp)
                            .background(Color.Red, RoundedCornerShape(50))
                            .padding(horizontal = 5.dp, vertical = 1.dp)
                    ) {
                        Text(text = "$notificationCount", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

/** Compteur de pièces réutilisable, dégradé signature TantArt. */
@Composable
fun CoinCounter(coins: Int, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(
                androidx.compose.ui.graphics.Brush.horizontalGradient(listOf(TantPurple, TantPink, TantOrange)),
                RoundedCornerShape(50)
            )
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(text = "🪙 $coins", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}
