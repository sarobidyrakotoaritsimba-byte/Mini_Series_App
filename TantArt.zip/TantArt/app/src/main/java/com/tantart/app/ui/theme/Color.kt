package com.tantart.app.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// ==== Palette de marque TantArt (source unique de vérité couleurs) ====
val TantPurple = Color(0xFF6A11CB)
val TantPink = Color(0xFFFF2DA8)
val TantOrange = Color(0xFFFF6A00)
val TantGold = Color(0xFFFFC107)
val TantBlue = Color(0xFF2196F3)

// Fonds / surfaces
val TantBackground = Color(0xFF0D0D12)
val TantSurface = Color(0xFF16161F)
val TantCard = Color(0xFF20202B)
val TantBottomNav = Color(0xFF121218)
val TantDialog = Color(0xFF262633)

// Texte
val TantTextPrimary = Color(0xFFFFFFFF)
val TantTextSecondary = Color(0xFFD9D9D9)
val TantTextMuted = Color(0xFFA0A0A0)

/** Dégradé signature TantArt : violet → rose → orange → or. */
val TantGradient = Brush.horizontalGradient(
    colors = listOf(TantPurple, TantPink, TantOrange, TantGold)
)

val TantGradientVertical = Brush.verticalGradient(
    colors = listOf(TantPurple, TantPink, TantOrange, TantGold)
)
