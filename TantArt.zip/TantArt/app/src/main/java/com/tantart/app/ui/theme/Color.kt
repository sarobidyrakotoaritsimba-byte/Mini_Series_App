package com.tantart.app.ui.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush

// Palette extraite de l'identité visuelle TantArt
val TantPurple = Color(0xFF7B2FF7)
val TantMagenta = Color(0xFFE63888)
val TantOrange = Color(0xFFFF7A30)
val TantBlue = Color(0xFF2D6CDF)
val TantBackground = Color(0xFF0B0B14)
val TantSurface = Color(0xFF16161F)
val TantGold = Color(0xFFFFC107)

/** Le dégradé signature de la marque, utilisé sur les CTA et accents. */
val TantGradient = Brush.horizontalGradient(
    colors = listOf(TantPurple, TantMagenta, TantOrange)
)

val TantGradientVertical = Brush.verticalGradient(
    colors = listOf(TantPurple, TantMagenta, TantOrange)
)
