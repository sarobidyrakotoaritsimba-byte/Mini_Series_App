package com.tantart.app.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.tantart.app.ui.theme.TantTextMuted
import com.tantart.app.ui.theme.TantTextPrimary

/** Écran temporaire pour les sections pas encore développées (Explorer, Ma liste, Profil). */
@Composable
fun PlaceholderScreen(title: String, message: String = "Bientôt disponible") {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
    ) {
        Text(text = title, color = TantTextPrimary, style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = message, color = TantTextMuted, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
    }
}
