package com.tantart.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.tantart.app.ui.components.PlaceholderScreen
import com.tantart.app.ui.components.TantBottomNavBar
import com.tantart.app.ui.feed.FeedScreen
import com.tantart.app.ui.home.HomeScreen
import com.tantart.app.ui.nav.TantScreen
import com.tantart.app.ui.theme.TantArtTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TantArtTheme {
                TantArtApp()
            }
        }
    }
}

/**
 * Racine de navigation de l'app. Accueil est l'écran de lancement.
 * Le Feed existant est ouvert en plein écran (immersif, sans barre de
 * navigation) depuis l'onglet "Feed" ou depuis les CTA de l'accueil ;
 * le bouton retour système ramène alors à l'Accueil.
 */
@Composable
private fun TantArtApp() {
    var currentScreen by remember { mutableStateOf(TantScreen.Home) }

    if (currentScreen == TantScreen.Feed) {
        BackHandler {
            currentScreen = TantScreen.Home
        }
        FeedScreen()
        return
    }

    Scaffold(
        bottomBar = {
            TantBottomNavBar(
                currentScreen = currentScreen,
                onScreenSelected = { currentScreen = it }
            )
        }
    ) { innerPadding ->
        androidx.compose.foundation.layout.Box(modifier = Modifier.padding(innerPadding)) {
            when (currentScreen) {
                TantScreen.Home -> HomeScreen(
                    onWatchHeroClick = { currentScreen = TantScreen.Feed },
                    onContinueWatchingClick = { currentScreen = TantScreen.Feed }
                )
                TantScreen.Explore -> PlaceholderScreen(
                    title = "Explorer",
                    message = "La recherche et l'exploration par genre arrivent bientôt."
                )
                TantScreen.MyList -> PlaceholderScreen(
                    title = "Ma liste",
                    message = "Retrouve ici les séries que tu as ajoutées."
                )
                TantScreen.Profile -> PlaceholderScreen(
                    title = "Profil",
                    message = "La gestion de compte arrive bientôt."
                )
                TantScreen.Feed -> Unit // géré au-dessus, plein écran
            }
        }
    }
}
