package com.tantart.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Masks
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TheaterComedy
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tantart.app.data.model.HomeCategory
import com.tantart.app.ui.theme.TantCard
import com.tantart.app.ui.theme.TantPink
import com.tantart.app.ui.theme.TantTextPrimary

// Mapping icônes établi à partir des visuels officiels TantArt fournis :
// masques de théâtre (Drame), cœur (Romance), loupe (Mystère), flamme (Action),
// masque simple (Thriller), smiley (Comédie).
private fun iconForCategory(name: String): ImageVector = when (name) {
    "Drame" -> Icons.Filled.TheaterComedy
    "Romance" -> Icons.Filled.Favorite
    "Mystère" -> Icons.Filled.Search
    "Action" -> Icons.Filled.Whatshot
    "Thriller" -> Icons.Filled.Masks
    "Comédie" -> Icons.Filled.EmojiEmotions
    else -> Icons.Filled.TheaterComedy
}

/** Section "Explorer par catégorie" : titre + rangée horizontale d'icônes/genres. */
@Composable
fun CategoryRow(
    categories: List<HomeCategory>,
    onCategoryClick: ((HomeCategory) -> Unit)? = null,
    onSeeAllClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        SectionHeader(title = "Explorer par catégorie", onSeeAllClick = onSeeAllClick)
        Spacer(modifier = Modifier.height(12.dp))
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(horizontal = 16.dp)
        ) {
            items(categories) { category ->
                CategoryChip(category = category, onClick = { onCategoryClick?.invoke(category) })
            }
        }
    }
}

@Composable
private fun CategoryChip(category: HomeCategory, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .width(78.dp)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(78.dp)
                .background(TantCard, RoundedCornerShape(20.dp)),
            contentAlignment = Alignment.Center
        ) {
            // L'icône n'occupe pas tout le carré : espace interne conservé
            // pour un rendu premium, comme dans les visuels de référence.
            Icon(
                imageVector = iconForCategory(category.name),
                contentDescription = category.name,
                tint = TantPink,
                modifier = Modifier.size(30.dp)
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = category.name,
            color = TantTextPrimary,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
            maxLines = 1
        )
    }
}
