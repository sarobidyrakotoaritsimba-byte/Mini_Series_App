package com.tantart.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TantColorScheme = darkColorScheme(
    primary = TantPurple,
    secondary = TantPink,
    tertiary = TantOrange,
    background = TantBackground,
    surface = TantSurface,
    surfaceVariant = TantCard,
    onPrimary = Color.White,
    onBackground = TantTextPrimary,
    onSurface = TantTextPrimary,
    onSurfaceVariant = TantTextSecondary
)

@Composable
fun TantArtTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = TantColorScheme,
        typography = TantTypography,
        content = content
    )
}
