package com.tantart.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val TantColorScheme = darkColorScheme(
    primary = TantPurple,
    secondary = TantMagenta,
    tertiary = TantOrange,
    background = TantBackground,
    surface = TantSurface,
    onPrimary = androidx.compose.ui.graphics.Color.White,
    onBackground = androidx.compose.ui.graphics.Color.White,
    onSurface = androidx.compose.ui.graphics.Color.White
)

@Composable
fun TantArtTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = TantColorScheme,
        content = content
    )
}
