package com.tantart.app.ui.nav

/**
 * Les écrans accessibles depuis la navigation principale.
 * Navigation volontairement simple (état local, pas de librairie Navigation)
 * pour rester léger tant que l'app n'a que quelques écrans.
 */
enum class TantScreen {
    Home,
    Explore,
    Feed,
    MyList,
    Profile
}
