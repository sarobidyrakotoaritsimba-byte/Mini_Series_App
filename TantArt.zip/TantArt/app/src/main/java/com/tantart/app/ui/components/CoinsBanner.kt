package com.tantart.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tantart.app.ui.theme.TantOrange
import com.tantart.app.ui.theme.TantPurple
import com.tantart.app.ui.theme.TantTextPrimary
import com.tantart.app.ui.theme.TantTextSecondary

/** Bannière incitative "Gagnez des coins" avec CTA vers les missions. */
@Composable
fun CoinsBanner(
    onSeeMissionsClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Brush.horizontalGradient(listOf(TantPurple.copy(alpha = 0.9f), TantOrange.copy(alpha = 0.7f))))
            .padding(20.dp)
    ) {
        Column(modifier = Modifier.width(220.dp)) {
            Text(text = "Gagnez des coins", color = TantTextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Regardez des vidéos, faites des missions et gagnez !",
                color = TantTextSecondary,
                fontSize = 13.sp
            )
            Spacer(modifier = Modifier.height(12.dp))
            Box(
                modifier = Modifier
                    .background(Color.White.copy(alpha = 0.18f), RoundedCornerShape(50))
                    .clickable(onClick = onSeeMissionsClick)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(text = "Voir les missions", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
