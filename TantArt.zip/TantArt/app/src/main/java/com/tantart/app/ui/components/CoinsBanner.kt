package com.tantart.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tantart.app.ui.theme.TantOrange
import com.tantart.app.ui.theme.TantPurple
import com.tantart.app.ui.theme.TantTextMuted
import com.tantart.app.ui.theme.TantTextPrimary

/**
 * Bannière incitative "Gagnez des coins" avec CTA vers les missions.
 * Illustration à droite : emoji cadeau + pièce en attendant un vrai asset
 * illustré (à remplacer facilement une fois disponible, voir
 * GiftIllustrationPlaceholder ci-dessous).
 */
@Composable
fun CoinsBanner(
    onSeeMissionsClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Brush.horizontalGradient(listOf(TantPurple.copy(alpha = 0.9f), TantOrange.copy(alpha = 0.7f))))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.width(200.dp)) {
                Text(text = "Gagnez des coins", color = TantTextPrimary, style = MaterialTheme.typography.titleLarge)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Regardez des vidéos, faites des missions et gagnez !",
                    color = TantTextMuted,
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(modifier = Modifier.height(12.dp))
                Box(
                    modifier = Modifier
                        .background(Color.White.copy(alpha = 0.18f), RoundedCornerShape(50))
                        .clickable(onClick = onSeeMissionsClick)
                        .padding(horizontal = 14.dp, vertical = 7.dp)
                ) {
                    Text(text = "Voir les missions", color = Color.White, style = MaterialTheme.typography.labelMedium)
                }
            }
            GiftIllustrationPlaceholder()
        }
    }
}

/**
 * Emplacement pour l'illustration "cadeau + pièces". Utilise des emojis en
 * attendant un vrai asset graphique — à remplacer par une Image/AsyncImage
 * pointant vers l'illustration finale sans changer l'appel dans CoinsBanner.
 */
@Composable
private fun GiftIllustrationPlaceholder() {
    Box(
        modifier = Modifier
            .size(64.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center
    ) {
        Text(text = "🎁", fontSize = 28.sp)
    }
}
