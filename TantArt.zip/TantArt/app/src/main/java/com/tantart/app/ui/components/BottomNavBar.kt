package com.tantart.app.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import com.tantart.app.ui.nav.TantScreen
import com.tantart.app.ui.theme.TantBottomNav
import com.tantart.app.ui.theme.TantPink
import com.tantart.app.ui.theme.TantTextMuted
import com.tantart.app.ui.theme.TantTextPrimary

private data class NavEntry(val screen: TantScreen, val label: String, val icon: ImageVector)

private val navEntries = listOf(
    NavEntry(TantScreen.Home, "Accueil", Icons.Filled.Home),
    NavEntry(TantScreen.Explore, "Explorer", Icons.Filled.Explore),
    NavEntry(TantScreen.Feed, "Feed", Icons.Filled.PlayCircle),
    NavEntry(TantScreen.MyList, "Ma liste", Icons.Filled.List),
    NavEntry(TantScreen.Profile, "Profil", Icons.Filled.Person)
)

/** Barre de navigation principale : Accueil, Explorer, Feed, Ma liste, Profil. */
@Composable
fun TantBottomNavBar(
    currentScreen: TantScreen,
    onScreenSelected: (TantScreen) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier,
        containerColor = TantBottomNav
    ) {
        navEntries.forEach { entry ->
            val isSelected = entry.screen == currentScreen
            NavigationBarItem(
                selected = isSelected,
                onClick = { onScreenSelected(entry.screen) },
                icon = { Icon(imageVector = entry.icon, contentDescription = entry.label) },
                label = {
                    Text(
                        text = entry.label,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = TantPink,
                    selectedTextColor = TantPink,
                    unselectedIconColor = TantTextMuted,
                    unselectedTextColor = TantTextMuted,
                    indicatorColor = TantBottomNav
                )
            )
        }
    }
}
