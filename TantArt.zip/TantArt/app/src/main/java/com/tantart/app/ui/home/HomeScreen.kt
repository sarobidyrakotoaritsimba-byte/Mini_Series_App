package com.tantart.app.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tantart.app.data.repository.HomeRepository
import com.tantart.app.ui.components.CategoryRow
import com.tantart.app.ui.components.CoinsBanner
import com.tantart.app.ui.components.ContinueWatchingSection
import com.tantart.app.ui.components.HeroBanner
import com.tantart.app.ui.components.HomeTabs
import com.tantart.app.ui.components.TopHeader
import com.tantart.app.ui.theme.TantBackground

/**
 * Page d'accueil TantArt : header, onglets, hero, reprendre la lecture,
 * catégories, bannière coins. Premier écran affiché au lancement.
 *
 * Les données viennent de HomeRepository (mock pour l'instant, mais déjà
 * structuré pour être remplacé par de vrais appels réseau).
 */
@Composable
fun HomeScreen(
    onWatchHeroClick: () -> Unit = {},
    onContinueWatchingClick: () -> Unit = {}
) {
    var selectedTab by remember { mutableStateOf("Pour vous") }
    val hero = remember { HomeRepository.getHero() }
    val continueWatching = remember { HomeRepository.getContinueWatching() }
    val categories = remember { HomeRepository.getCategories() }

    Column(modifier = Modifier.fillMaxSize().background(TantBackground)) {
        TopHeader(coins = 560, notificationCount = 3)
        HomeTabs(selectedTab = selectedTab, onTabSelected = { selectedTab = it })
        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            item {
                HeroBanner(
                    hero = hero,
                    onWatchClick = onWatchHeroClick,
                    onAddToListClick = {},
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }
            item {
                ContinueWatchingSection(
                    items = continueWatching,
                    onItemClick = { onContinueWatchingClick() }
                )
            }
            item {
                CategoryRow(categories = categories)
            }
            item {
                CoinsBanner()
            }
            item {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
